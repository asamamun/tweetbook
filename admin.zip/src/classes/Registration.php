<?php
namespace App\classes;
class Registration{
    function saveuser(){
        return "you called save user";
    }
}