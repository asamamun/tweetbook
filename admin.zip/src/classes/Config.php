<?php
namespace App\classes;
class Config{
    public static function siteinfo(){
        return [
            'baseurl'=>'http://localhost/R45/PHP/classes/PROJECT/tweetbook/',
            'pagesize'=>10,
        ];
    }
}