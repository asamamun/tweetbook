<?php
namespace App\classes;
class Login{
    function check(){
        return "you called check";
    }
}